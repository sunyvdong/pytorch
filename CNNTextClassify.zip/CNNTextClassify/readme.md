# 模型架构

## TextCNN Architecture

<center>Input (Sequence of Texts)</center>  
<center>|</center>  
<center>v</center>  
<center>Embedding Layer (Randomly initialize Embedding)</center>  
<center>|</center>  
<center>v</center>  
<center>Convolutional Layers (with filter sizes: 3, 4, 5)</center>  
<center>|</center>  
<center>v</center>  
<center>Max Pooling Layers</center>  
<center>|</center>  
<center>v</center>  
<center>Concatenation of Pooled Features</center>  
<center>|</center>  
<center>v</center>  
<center>Dropout Layer (dropout probability: 0.5)</center>  
<center>|</center>  
<center>v</center>  
<center>Fully Connected Layer (number of filters: 100)</center>  
<center>|</center>  
<center>v</center>  
<center>Output (number of classes: 10)</center>

# 模型效果

在测试集上 Accuracy: 88.66%
# 权重

权重保存在`./snapshot/`目录下

# API
API接口
```python
python api.py
```
    
API接口测试
```python
python api_test.py
```

# 参考

https://github.com/practicingman/chinese_text_cnn/tree/master
