# main.py

from typing import List
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel
import torch
import model
from datasets import  load_vocab, load_stopwords, load_label_names, id_to_label, texts_to_tensor
import os
import argparse



os.chdir(os.path.dirname(os.path.abspath(__file__)))

parser = argparse.ArgumentParser(description='TextCNN text classifier')
# learning
parser.add_argument('-lr', type=float, default=0.001, help='initial learning rate [default: 0.001]')
parser.add_argument('-epochs', type=int, default=256, help='number of epochs for train [default: 256]')
parser.add_argument('-batch-size', type=int, default=128, help='batch size for training [default: 128]')
parser.add_argument('-log-interval', type=int, default=1, help='how many steps to wait before logging training status [default: 1]')
parser.add_argument('-test-interval', type=int, default=100, help='how many steps to wait before testing [default: 100]')
parser.add_argument('-save_dir', type=str, default='../snapshot', help='where to save the snapshot')
parser.add_argument('-early-stopping', type=int, default=10, help='iteration numbers to stop without performance increasing')
parser.add_argument('-save-best', type=bool, default=True, help='whether to save when get best performance')
# model
parser.add_argument('-dropout', type=float, default=0.5, help='the probability for dropout [default: 0.5]')
parser.add_argument('-max-norm', type=float, default=3.0, help='l2 constraint of parameters [default: 3.0]')
parser.add_argument('-embedding-dim', type=int, default=128, help='number of embedding dimension [default: 128]')
parser.add_argument('-filter-num', type=int, default=100, help='number of each size of filter')
parser.add_argument('-filter-sizes', type=str, default='3,4,5',
                    help='comma-separated filter sizes to use for convolution')

parser.add_argument('-static', type=bool, default=False, help='whether to use static pre-trained word vectors')
parser.add_argument('-non-static', type=bool, default=False, help='whether to fine-tune static pre-trained word vectors')
parser.add_argument('-multichannel', type=bool, default=False, help='whether to use 2 channel of word vectors')
parser.add_argument('-pretrained-name', type=str, default='sgns.zhihu.word',
                    help='filename of pre-trained word vectors')
parser.add_argument('-pretrained-path', type=str, default='pretrained', help='path of pre-trained word vectors')
# device
parser.add_argument('-device', type=int, default=0, help='device to use for iterate data, -1 mean cpu [default: -1]')
# data
parser.add_argument('-data-path', type=str, default='../data/', help='root path of all data')
parser.add_argument('-train_file', type=str, default='train.txt', help='train file')
parser.add_argument('-dev_file', type=str, default='dev.txt', help='dev file')
parser.add_argument('-loss_save_dir', type=str, default='../loss/', help='root path of all data')
parser.add_argument('-text_vocab_file', type=str, default='../data/text_vocab.json', help='text vocabulary file')
parser.add_argument('-label_vocab_file', type=str, default='../data/label_vocab.json', help='label vocabulary file')
parser.add_argument('-label_names', type=str, default='../data/class.txt', help='label vocabulary file')
parser.add_argument('-stopwords_file', type=str, default='../data/baidu_stopwords.txt', help='stopwords file')
# option
parser.add_argument('-snapshot', type=str, default=None, help='filename of model snapshot [default: None]')
# pattern
parser.add_argument('-pattern', type=str, default='train', help='train or test')

args = parser.parse_args()


# 加载词汇表
text_vocab = load_vocab(args.text_vocab_file)
label_vocab = load_vocab(args.label_vocab_file)
stop_words = load_stopwords(args.stopwords_file)
label_names = load_label_names(args.label_names)

# 设置参数
args.class_num = len(label_vocab)
args.vocabulary_size = len(text_vocab)  # 设置 vocabulary_size
args.filter_sizes = [int(size) for size in args.filter_sizes.split(',')]

# 加载模型
model = model.TextCNN(args)
model.load_state_dict(torch.load('../snapshot/best_epoch_20.pt'))
device = 'cuda' if torch.cuda.is_available() else 'cpu'
model.to(device)
model.eval()





# 创建 FastAPI 应用
app = FastAPI()

# 定义请求体模型
class TextRequest(BaseModel):
    texts: List[str]


# 全局异常处理器
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=422,
        content={
            "detail": [
                {
                    "loc": error["loc"],
                    "msg": "Invalid input type. Please provide a list of strings for 'texts'.",
                    "input": error["input"]
                }
                for error in exc.errors()
            ]
        },
    )

# 路由处理函数
@app.post("/classify", response_model=List[str])
async def predict(input_data: TextRequest):
    texts = input_data.texts
    # 检查输入是否为空
    if not texts or all(not text.strip() for text in texts):
        raise HTTPException(status_code=400, detail="Input texts cannot be empty or whitespace only.")
    
    # 检查输入类型
    if not all(isinstance(text, str) for text in texts):
        raise HTTPException(status_code=400, detail="Input texts must be a list of strings.")    
    
    input_tensors = texts_to_tensor(texts=texts, text_vocab=text_vocab, stopwords=stop_words, pad_idx=text_vocab['<pad>']).to(device)
    
    try:
        with torch.no_grad():
            outputs = model(input_tensors)
            predicted_label_idxs = torch.argmax(outputs, dim=1).tolist()
        
        predictions_labels = [id_to_label(idx, label_vocab) for idx in predicted_label_idxs]
        predicted_label_names = [label_names[int(lable)] for lable in predictions_labels]

        return predicted_label_names  # 直接返回预测结果的列表
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
# 如果需要，也可以添加一个简单的根路由来确认服务是否运行
@app.get("/")
async def read_root():
    return {"message": "Welcome to Medical Text Classification API."}

# 启动 FastAPI 应用
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)

    # r = predict( {"texts": ["这是一段医学文本。", "这是另一段医学文本。"]})
    # print(r)