import os
import sys
import torch
import model



def test_model(model, test_loader, criterion, device):
    
    model.eval()
    total_loss = 0
    corrects = 0
    with torch.no_grad():
        for batch in test_loader:
            texts, labels, original_texts, original_labels = batch
            texts, labels = texts.to(device), labels.to(device)
            outputs = model(texts)
            loss = criterion(outputs, labels)
            total_loss += loss.item()
            corrects += (torch.max(outputs, 1)[1] == labels).sum().item()
    avg_loss = total_loss / len(test_loader)
    accuracy = 100.0 * corrects / len(test_loader.dataset)
    return avg_loss, accuracy


# 进行测试
def test(test_loader, text_cnn, args):
    # 初始化模型
    text_cnn = model.TextCNN(args)
    
    # 加载最佳模型
    best_model_path = find_best_model(args.save_dir)
    if best_model_path:
        print(f"Loading best model from {best_model_path}")
        text_cnn.load_state_dict(torch.load(best_model_path))
    else:
        print("Best model not found. Aborting test.")
        return

    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    text_cnn.to(device)

    # 定义损失函数
    criterion = torch.nn.CrossEntropyLoss()

    # 测试模型
    test_loss, test_accuracy = test_model(text_cnn, test_loader, criterion, device)
    
    print(f'Test Loss: {test_loss:.4f}, Test Accuracy: {test_accuracy:.2f}%')

def find_best_model(save_dir):
    import glob
    import re
    
    pattern = re.compile(r'best_epoch_(\d+).pt')
    best_epoch = -1
    best_model_path = None
    
    for filename in glob.glob(os.path.join(save_dir, '*.pt')):
        match = pattern.search(filename)
        if match:
            epoch = int(match.group(1))
            if epoch > best_epoch:
                best_epoch = epoch
                best_model_path = filename
    
    return best_model_path