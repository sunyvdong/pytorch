import json
import os
import jieba
import torch
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence
import torch.nn.functional as F
from collections import Counter, defaultdict

# 自定义分词函数
def word_cut(sentence, stopwords):
    words = jieba.cut(sentence)
    return [word for word in words if word not in stopwords]
    
# text_2_ids函数用于将文本转换为索引
def preprocess_text(text, text_vocab, stopwords):
    tokenized_text = [text_vocab.get(token, text_vocab['<unk>']) for token in word_cut(text, stopwords)]
    return tokenized_text

# 将文本转换为张量
def texts_to_tensor(texts, text_vocab, stopwords, pad_idx):
    tokenized_texts = [torch.tensor(preprocess_text(text, text_vocab, stopwords), dtype=torch.long) for text in texts]
    padded_texts = pad_sequence(tokenized_texts, batch_first=True, padding_value=pad_idx)
    return padded_texts

def text_to_ids(text, text_vocab, stopwords):
    # 分词并去除停用词
    tokens = word_cut(text, stopwords)    
    # 将词语转换为索引，未登录词使用 <unk> 的索引
    ids = [text_vocab.get(token, text_vocab['<unk>']) for token in tokens]
    return ids

def id_to_label(label_idx, label_vocab):
    for label, idx in label_vocab.items():
        if idx == label_idx:
            return label
    return None  # 如果找不到对应的标签ID，则返回None或其他适当的值

def label_to_class_name(label, class_names):
    return class_names[label]

# 定义数据集类
class TextDataset(Dataset):
    def __init__(self, texts, labels, text_vocab, label_vocab, stopwords):
        self.texts = texts
        self.labels = labels
        self.text_vocab = text_vocab
        self.label_vocab = label_vocab
        self.stopwords = stopwords
        self.unk_idx = text_vocab['<unk>']
        self.pad_idx = text_vocab['<pad>']

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        text = self.texts[idx]
        label = self.labels[idx]
        tokenized_text = [self.text_vocab.get(token, self.unk_idx) for token in word_cut(text, self.stopwords)]
        label_idx = self.label_vocab[label]
        return torch.tensor(tokenized_text, dtype=torch.long), torch.tensor(label_idx, dtype=torch.long), text, label



# 构建词汇表函数
def build_vocab_from_iterator(iterator, specials=['<unk>', '<pad>']):
    counter = Counter()
    for sentence in iterator:
        counter.update(sentence)
    
    sorted_by_freq_tuples = sorted(counter.items(), key=lambda x: (-x[1], x[0]))
    ordered_dict = {word: idx for idx, (word, _) in enumerate(sorted_by_freq_tuples, len(specials))}
    for idx, token in enumerate(specials):
        ordered_dict[token] = idx
    return ordered_dict

# 数据加载和预处理的函数
def collate_fn(batch, pad_idx=1):  # Assuming <pad> token has index 1
    texts, labels, original_texts, original_labels = zip(*batch)
    lengths = [len(text) for text in texts]
    max_len = max(lengths)
    padded_texts = [F.pad(text, (0, max_len - len(text)), value=pad_idx) for text in texts]
    texts_tensor = torch.stack(padded_texts)
    labels_tensor = torch.tensor(labels)
    return texts_tensor, labels_tensor, original_texts, original_labels

# 保存词汇表函数
def save_vocab(vocab, vocab_file):
    with open(vocab_file, 'w', encoding='utf-8') as f:
        json.dump(vocab, f, ensure_ascii=False, indent=4)

# 加载json格式词汇表
def load_vocab(vocab_file):
    if not os.path.exists(vocab_file):
        return None
    with open(vocab_file, 'r', encoding='utf-8') as f:
        vocab = json.load(f)
    return vocab

# 加载json格式lable表
def load_labels(file):
    with open(file, 'r', encoding='utf-8') as f:
        labels = json.load(f)
    return labels

# 加载停用词列表
def load_stopwords(file):
    with open(file, 'r', encoding='utf-8') as f:
        return set(line.strip() for line in f)
    
# 加载类别名称列表
def load_label_names(file):
    with open(file, 'r', encoding='utf-8') as f:
        label_names = [line.strip() for line in f]
    return label_names

# 加载数据
def load_dataset(path, train_file, dev_file, stopwords_file, text_vocab_file=None, label_vocab_file=None):
    def read_data(file):
        texts, labels = [], []
        with open(os.path.join(path, file), 'r', encoding='utf-8') as f:
            for line in f.readlines()[1:]:  # Skip the header
                parts = line.strip().split('\t')
                labels.append(parts[1])
                texts.append(parts[0])
        return texts, labels
    
    stopwords = load_stopwords(os.path.join(path, stopwords_file))
    
    train_texts, train_labels = read_data(train_file)
    dev_texts, dev_labels = read_data(dev_file)
    
    # 加载或重新构建文本词汇表
    if text_vocab_file:
        text_vocab = load_vocab(text_vocab_file)
    if text_vocab is None:
        text_vocab = build_vocab_from_iterator(
            (word_cut(text, stopwords) for text in train_texts), 
            specials=['<unk>', '<pad>']
        )
        if text_vocab_file:
            save_vocab(text_vocab, text_vocab_file)
    
    # 加载或重新构建标签词汇表
    if label_vocab_file:
        label_vocab = load_vocab(label_vocab_file)
    if label_vocab is None:
        label_vocab = build_vocab_from_iterator([train_labels])
        if label_vocab_file:
            save_vocab(label_vocab, label_vocab_file)

    pad_idx = text_vocab['<pad>']
    
    train_dataset = TextDataset(train_texts, train_labels, text_vocab, label_vocab, stopwords)
    dev_dataset = TextDataset(dev_texts, dev_labels, text_vocab, label_vocab, stopwords)
    
    return train_dataset, dev_dataset, text_vocab, label_vocab, pad_idx

