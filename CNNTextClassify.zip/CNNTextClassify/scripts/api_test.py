import requests
import time

def test_api(url, data):
    start_time = time.time()
    response = requests.post(url, json=data)
    end_time = time.time()

    response_time = end_time - start_time
    status_code = response.status_code
    try:
        response_json = response.json()
    except ValueError:
        response_json = None

    return {
        "status_code": status_code,
        "response_time": response_time,
        "response_json": response_json,
        "response_text": response.text
    }

def print_test_result(test_case, result):
    print(f"Test Case: {test_case['description']}")
    print(f"Status Code: {result['status_code']}")
    print(f"Response Time: {result['response_time']:.4f} seconds")
    print(f"Response JSON: {result['response_json']}")
    print("-" * 50)

url = 'http://127.0.0.1:8000/classify'



test_cases = [
    {
        "description": "Normal input texts",
        "data": {
            "texts": ["本科未录取还有这些路可以走", "2009年成人高考招生统一考试时间表"]
        }
    },
    {
        "description": "Empty input texts",
        "data": {
            "texts": [""]
        }
    },
    {
        "description": "Special characters input texts",
        "data": {
            "texts": ["@#$%^&*()_+!", "~~~`"]
        }
    },
    {
        "description": "Long input texts",
        "data": {
            "texts": ["这是一个非常长的文本" * 1000]
        }
    },
    {
        "description": "Mixed input texts",
        "data": {
            "texts": ["正常文本", "", "@#$%^&*()_+!", "长文本" * 100]
        }
    },
    {
        "description": "Invalid data type",
        "data": {
            "texts": 12345
        }
    }
]

for test_case in test_cases:
    result = test_api(url, test_case["data"])
    print_test_result(test_case, result)