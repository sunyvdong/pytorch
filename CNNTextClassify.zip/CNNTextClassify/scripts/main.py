import argparse
import torch
from torch.utils.data import DataLoader
import torch.nn.functional as F

from datasets import load_dataset, collate_fn
import model
import train
import test

import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

from config import args

# 加载数据集
print('Loading data...')

train_dataset, dev_dataset, text_vocab, label_vocab, pad_idx = load_dataset(
    path=args.data_path,
    train_file=args.train_file,
    dev_file=args.dev_file,
    stopwords_file=args.stopwords_file,
    text_vocab_file=args.text_vocab_file,  # 词汇表文件路径
    label_vocab_file=args.label_vocab_file  # 标签词汇表文件路径
)

train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, collate_fn=collate_fn)
dev_loader = DataLoader(dev_dataset, batch_size=args.batch_size, shuffle=False, collate_fn=collate_fn)
test_loader = DataLoader(dev_dataset, batch_size=args.batch_size, shuffle=False, collate_fn=collate_fn)

# 设置参数
args.class_num = len(label_vocab)
args.vocabulary_size = len(text_vocab)  # 设置 vocabulary_size
args.cuda = args.device != -1 and torch.cuda.is_available()
args.filter_sizes = [int(size) for size in args.filter_sizes.split(',')]

print('Parameters:')
for attr, value in sorted(args.__dict__.items()):
    if attr in {'vectors'}:
        continue
    print('\t{}={}'.format(attr.upper(), value))

# 初始化模型
text_cnn = model.TextCNN(args)
if args.snapshot:
    print('\nLoading model from {}...\n'.format(args.snapshot))
    text_cnn.load_state_dict(torch.load(args.snapshot))

if args.cuda:
    torch.cuda.set_device(args.device)
    text_cnn = text_cnn.cuda()

if args.pattern == 'train':
    # 开始训练
    try:
        train.train(train_loader, dev_loader, text_cnn, args)
    except KeyboardInterrupt:
        print('Exiting from training early')
else:
    # 开始测试
    test.test(test_loader, text_cnn, args)
