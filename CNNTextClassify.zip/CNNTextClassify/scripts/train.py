import os
import sys
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
from tqdm import tqdm


def train_model(model, train_loader, optimizer, criterion, device):
    model.train()
    total_loss = 0
    for batch in train_loader:
        texts, labels, original_texts, original_labels = batch
        texts, labels = texts.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(texts)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(train_loader)

def evaluate_model(model, dev_loader, criterion, device):
    
    model.eval()
    total_loss = 0
    corrects = 0
    with torch.no_grad():
        for batch in dev_loader:
            texts, labels, original_texts, original_labels = batch
            texts, labels = texts.to(device), labels.to(device)
            outputs = model(texts)
            loss = criterion(outputs, labels)
            total_loss += loss.item()
            corrects += (torch.max(outputs, 1)[1] == labels).sum().item()
    avg_loss = total_loss / len(dev_loader)
    accuracy = 100.0 * corrects / len(dev_loader.dataset)
    return avg_loss, accuracy

def train(train_loader, dev_loader, model, args):
    device = torch.device("cuda" if torch.cuda.is_available() and args.device != -1 else "cpu")
    model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    criterion = torch.nn.CrossEntropyLoss()

    best_acc = 0
    last_step = 0
    train_losses, valid_losses = [], []

    for epoch in tqdm(range(1, args.epochs + 1)):
        train_loss = train_model(model, train_loader, optimizer, criterion, device)
        valid_loss, valid_acc = evaluate_model(model, dev_loader, criterion, device)
        train_losses.append(train_loss)
        valid_losses.append(valid_loss)

        print(f'Epoch: {epoch:02}, Train Loss: {train_loss:.4f}, Val Loss: {valid_loss:.4f}, Val Acc: {valid_acc:.2f}%')

        if valid_acc > best_acc:
            best_acc = valid_acc
            last_step = epoch
            if args.save_best:
                print(f'Saving best model, acc: {best_acc:.4f}%')
                save(model, args.save_dir, 'best', epoch)
        else:
            if epoch - last_step >= args.early_stopping:
                print(f'Early stopping triggered. Best Val Acc: {best_acc:.2f}%')
                break
        
        plot_loss(train_losses, valid_losses, args.loss_save_dir)

def plot_loss(train_losses, valid_losses, save_dir):
    plt.figure(figsize=(10, 5))
    plt.plot(train_losses, label='Train Loss')
    plt.plot(valid_losses, label='Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.title('Training and Validation Loss over Epochs')

    # Save the figure to the specified directory
    if not os.path.isdir(save_dir):
        os.makedirs(save_dir)
    save_path = os.path.join(save_dir, 'loss_curve.png')
    plt.savefig(save_path)
    print(f'Loss curve saved to {save_path}')

def save(model, save_dir, save_prefix, epoch):
    if not os.path.isdir(save_dir):
        os.makedirs(save_dir)
    save_prefix = os.path.join(save_dir, save_prefix)
    save_path = f'{save_prefix}_epoch_{epoch}.pt'
    torch.save(model.state_dict(), save_path)
